// ─── Máscara de CEP ──────────────────────────────────────────────────
const cepInput = document.getElementById("cep");

cepInput.addEventListener("input", () => {
    let valor = cepInput.value.replace(/\D/g, "");
    if (valor.length > 8) valor = valor.slice(0, 8);
    valor = valor.replace(/^(\d{5})(\d)/, "$1-$2");
    cepInput.value = valor;
});

// ─── Busca CEP via ViaCEP ────────────────────────────────────────────
cepInput.addEventListener("blur", async () => {

    const cep = cepInput.value.replace(/\D/g, "");

    if (cep.length !== 8) {
        alert("Digite um CEP válido.");
        return;
    }

    try {
        const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
        const dados = await response.json();

        if (dados.erro) {
            alert("CEP não encontrado.");
            return;
        }

        document.getElementById("logradouro").value = dados.logradouro || "";
        document.getElementById("bairro").value     = dados.bairro     || "";
        document.getElementById("localidade").value = dados.localidade || "";
        document.getElementById("uf").value         = dados.uf         || "";

        document.getElementById("endereco-container").style.display = "block";

    } catch (error) {
        alert("Erro ao consultar CEP.");
    }
});

// ─── Máscara de telefone ─────────────────────────────────────────────
const telefone = document.getElementById("cellphone");

telefone.addEventListener("input", function () {
    let valor = this.value.replace(/\D/g, "");

    if (valor.length > 11) valor = valor.slice(0, 11);

    valor = valor.replace(/^(\d{2})(\d)/, "($1) $2");
    valor = valor.replace(/(\d{5})(\d)/, "$1-$2");

    this.value = valor;
});

// ─── Suporte a PASTE no telefone ─────────────────────────────────────
telefone.addEventListener("paste", function (e) {
    e.preventDefault();
    const colado = (e.clipboardData || window.clipboardData)
        .getData("text")
        .replace(/\D/g, "")
        .slice(0, 11);

    this.value = colado;
    this.dispatchEvent(new Event("input"));
});

// ─── Submit ──────────────────────────────────────────────────────────
const form = document.getElementById("form");

form.addEventListener("submit", function (event) {
    event.preventDefault();

    const nome    = document.getElementById("name").value.trim();
    const celular = document.getElementById("cellphone").value.trim();
    const consumo = document.getElementById("type").value;

    if (!nome || !celular || !consumo) {
        alert("Por favor, é necessário preencher todos os dados");
        return;
    }

    let consumokWh;
    switch (consumo) {
        case "first":  consumokWh = 150;  break;
        case "second": consumokWh = 250;  break;
        case "third":  consumokWh = 400;  break;
        case "fourth": consumokWh = 650;  break;
        case "fifth":  consumokWh = 1500; break;
        case "sixth":  consumokWh = 5000; break;
        default:       consumokWh = 0;    break;
    }

    const geracaoPorPlaca = 75;
    const custoPorPlaca   = 2050;
    const tarifaMedia     = 0.80;

    const placas         = Math.ceil(consumokWh / geracaoPorPlaca);
    const precoTotal     = placas * custoPorPlaca;
    const economiaMensal = (consumokWh * tarifaMedia).toFixed(2);
    const retornoMeses   = Math.ceil(precoTotal / economiaMensal);
    const retornoAnos    = (retornoMeses / 12).toFixed(1);
    const precoComMdO    = precoTotal * 1.20;

    const formatarReais = (valor) =>
        new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(valor);

    document.getElementById("container").innerHTML = `
      <div class="resultado">
        <h2>Olá, ${nome}! Veja sua estimativa!</h2>
        <h4>(Os valores podem sofrer ajustes)</h4>
        <div class="card-resultado">
          <div class="item">
            <span class="label">Consumo estimado</span>
            <span class="valor">${consumokWh} kWh/mês</span>
          </div>
          <div class="item">
            <span class="label">Placas necessárias</span>
            <span class="valor">${placas} placas (550W cada)</span>
          </div>
          <div class="item">
            <span class="label">Investimento estimado</span>
            <span class="valor">${formatarReais(precoTotal)}</span>
          </div>
          <div class="item">
            <span class="label">Investimento com mão de obra</span>
            <span class="valor">${formatarReais(precoComMdO)}</span>
          </div>
          <div class="item">
            <span class="label">Economia mensal estimada</span>
            <span class="valor">${formatarReais(economiaMensal)}</span>
          </div>
          <div class="item">
            <span class="label">Retorno do investimento</span>
            <span class="valor">${retornoAnos} anos (${retornoMeses} meses)</span>
          </div>
        </div>
        <p class="aviso">Valores estimados com base em médias nacionais. Entre em contato para um orçamento personalizado.</p>
        <button class="btn-refazer" onclick="location.reload()">Refazer simulação</button>
      </div>
    `;
});